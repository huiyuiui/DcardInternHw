# DcardInternHw

## Python code
<li> <b>model.ipynb</b>
<li> 根據檔案內所import的package安裝環境
<li> torch version = 1.12.1+cu113
<li> cuda version = 11.3
<li> 安裝好環境後直接按下全部執行便可以得到訓練過程及結果

## 實作過程及實驗和想法
<li> <b>report.pdf</b>
<li> 可以參考內容並搭配code以了解細節